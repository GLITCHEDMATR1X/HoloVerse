HoloVerse drop-in (Pass 282.75)

Copy these four files over the same paths in your HoloVerse folder:
  main.py
  holoverse_child_bootstrap.py
  holoverse/dimension_planets.py
  holoverse/dimensions/registry.py
No dimension project needs an edit.

Checked: all 17 linked MatrixCore dimensions open through HoloVerse's real launch route (Gleebs' archive,
HoloSpace planets, guide bots) and return with HoloVerse's controls and window intact.

Display standard - every dimension uses HoloVerse's display:
- Same-window dimensions never change HoloVerse's window (size, position, fullscreen, borders) - verified.
- Games in their own window open at HoloVerse's actual size and position: Operation StarFall (was a quarter-size
  window in the top-left), Vector Wars and Afterlife of IO (were their own 1920x1080, centred).

Controls:
- Dimensions that take their keys from HoloVerse (HoloUtopia, Zonez, HoloTactics, Vector Arena) now get them.
- The Indigo Giant keeps a visible cursor. These fixes now also apply when a dimension opens from Gleebs'
  archive, a HoloSpace planet or a guide (they only applied to one launch route before).

Also:
- Every linked dimension is a HoloSpace planet (17). Gleebs' archive list keeps each reality LOCKED until you
  enter its planet; the unlock is saved in dimension_archive.json in your save folder
  (Windows: %LOCALAPPDATA%\GLITCHED MATRIX\HoloVerse\).
- The Archivist opens; its book links no longer freeze HoloVerse; Zonez's exit works; no UI leak after Zonez.
- Hub artifacts: the E prompt shows wherever E works (~12 m) and a level view counts.
