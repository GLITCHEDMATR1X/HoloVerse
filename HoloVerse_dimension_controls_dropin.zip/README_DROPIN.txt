HoloVerse drop-in (Pass 282.78)

Copy everything in this zip into your HoloVerse folder (same paths; overwrite when asked):
  main.py, holoverse_child_bootstrap.py,
  holoverse/deep_space.py, holoverse/deep_space_combat.py, holoverse/deep_space_holohud.py,
  holoverse/holospace_cockpit_config.py, holoverse/dimension_planets.py, holoverse/fungal_visuals.py,
  holoverse/dimensions/registry.py,
  assets/config/holospace_cockpit.json   (keep your own copy if you already edited it),
  ui/ui_manifest.json, matrixcore/gleebs_dialogue.json

This pass - quality of life:
HoloSpace
- T  nav lock: cycles through every planet and Dyson Prime. A marker sits on the target (an arrow at the screen
     edge when it is behind you) with its archive status and how close you are to its defence perimeter.
- 1-5  throttle presets: 0 / 25 / 50 / 75 / 100 %.
- Flight now follows your mouse sensitivity and the Invert Y setting.
- Hit marker on the reticle when a laser hits (red when it destroys a ship).
Dimensions
- "ENTERING <NAME> // LOADING" card is shown while a dimension loads (the screen used to freeze on the hub).
- Pause screen (ESC in dimensions without their own pause) has clickable RESUME and RETURN TO MATRIXCORE.
- Gleebs' archive shows how many realities you have unlocked (UNLOCKED x/y).

Still included: Zonez removed, real pause in dimensions, corner holo HUD, defence wings, shields/hull and hub
respawn, editable cockpit, lasers, boost, asteroid fields, planets and archive unlocks, dimension
controls/display fixes, hub artifacts.
