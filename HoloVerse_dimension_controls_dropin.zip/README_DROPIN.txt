HoloVerse drop-in: dimension controls

Replace main.py in your HoloVerse folder with the one in this zip. No dimension project needs an edit.

Fixes (checked by mounting all nine MatrixCore native dimensions in HoloVerse):
- HoloUtopia and Zonez had no controls. They take their keys from HoloVerse (on_host_action / host.keys),
  but since Pass 282.16 HoloVerse unregisters its own controls on entry, so nothing reached them.
  HoloVerse now forwards keys to a dimension that has that hook and registers no keys of its own.
- The Archivist failed to open ("No module named 'archive3d'"): its folder is now importable while mounted.
- The Indigo Giant keeps a visible cursor (from the previous drop-in).
TAB still always returns to HoloVerse, and HoloVerse's own controls are restored on return.
