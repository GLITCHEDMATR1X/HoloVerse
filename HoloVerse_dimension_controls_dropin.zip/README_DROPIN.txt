HoloVerse drop-in (Pass 282.75)

Copy these three files over the same paths in your HoloVerse folder:
  main.py
  holoverse/dimension_planets.py
  holoverse/dimensions/registry.py
No dimension project needs an edit.

New in this drop-in:
- Operation StarFall (and any game that opens in its own window) now opens at HoloVerse's actual window size,
  position and mode. It used the saved launch size (1920x1080) at the top-left corner, which on a larger
  display was a quarter-size window.
- Every linked dimension is a planet in HoloSpace (17 with the current MatrixCore Project), including the ones
  a guide hosts in the world: The Indigo Giant, Mirror's Limbo, Afterlife of IO, The Archivist, Vector Wars,
  Anatomic, Glyphbound.
- Gleebs' Dimension Archive list: every reality starts LOCKED. Entering its planet in HoloSpace unlocks it,
  saved as planet_unlocked in dimension_archive.json in your save folder
  (Windows: %LOCALAPPDATA%\GLITCHED MATRIX\HoloVerse\). Guide bots still open their own dimensions.

Earlier fixes still included:
- HoloUtopia and Zonez controls; The Archivist opens; its book links no longer freeze HoloVerse; Zonez's exit
  works; no button leak after Zonez; Indigo Giant keeps a visible cursor.
- Hub artifacts: the E prompt shows wherever E works (~12 m) and a level view counts.
