HoloVerse drop-in: dimension controls

Replace main.py in your HoloVerse folder with the one in this zip. No dimension project needs an edit.
Checked by mounting all nine MatrixCore native dimensions in HoloVerse, three round trips each.

- HoloUtopia and Zonez had no controls: they take their keys from HoloVerse, which unregisters its own
  controls on entry. HoloVerse now forwards keys to a dimension that has that hook and binds no keys itself.
- The Archivist failed to open ("No module named 'archive3d'"): its folder is now importable while mounted.
- The Archivist's book links froze HoloVerse (they fell back to a blocking subprocess). Linked realities with
  a native adapter (Archive Echo) now open in the same window; others are refused without freezing.
- Zonez's in-game exit did nothing (it asks HoloVerse for return_to_hub / request_dimension_return): fixed.
- Zonez left 17 dead button listeners behind on every visit: orphaned dimension UI is now destroyed on return.
- The Indigo Giant keeps a visible cursor (from the previous drop-in).
TAB still always returns to HoloVerse, and HoloVerse's own controls are restored on return.
