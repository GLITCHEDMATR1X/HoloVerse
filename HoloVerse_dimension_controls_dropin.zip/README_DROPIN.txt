HoloVerse drop-in (Pass 282.75)

Copy these files over the same paths in your HoloVerse folder:
  main.py
  holoverse_child_bootstrap.py
  holoverse/deep_space.py
  holoverse/dimension_planets.py
  holoverse/fungal_visuals.py
  holoverse/dimensions/registry.py
No dimension project needs an edit.

HoloSpace (new):
- Octagonal canopy: a clear octagon window framed by tinted glass, struts and glowing trim. C cycles the cockpit
  colours (Cyan, Violet, Amber, Emerald); the window itself stays clear in every theme.
- Left click fires twin lasers: a hit asteroid breaks apart (shot rocks stay gone for the session). Clicking while
  aiming at a planet still opens that planet.
- Hold Shift to boost; boost energy drains while held and refills after you let go (shown under the speed).
- Asteroid fields stream out to about 10 km (was ~7.5 km) and fade in with distance and when they appear, instead
  of popping in. Collisions only check nearby space and the field placement was reworked, so the larger area
  costs about the same per frame.
- The cyan survey ring around asteroids is gone.
- All 17 dimension planets are in the sky, none overlapping each other or Dyson Prime.
Mushroom region: the ringed gas giant in the sky no longer shows the back of its ring through the planet.

Earlier fixes included: all dimensions open with working controls through every launch route; own-window games
(Operation StarFall, Vector Wars, Afterlife of IO) open at HoloVerse's size and position; every dimension is a
HoloSpace planet and Gleebs' archive unlocks a reality when you enter its planet (saved in your save folder);
hub artifacts activate from a normal standing view.
