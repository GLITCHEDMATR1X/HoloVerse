HoloVerse drop-in: native-dimension input fix (candidate)

Replace main.py in your HoloVerse folder with the one in this zip. Nothing else changes.

What it does:
- While a same-window dimension (e.g. The Indigo Giant) is active, HoloVerse unregisters its own
  controls, which also froze HoloVerse's key map (host.keys). A dimension adapter that reads that
  map saw every movement key as released. A passive mirror now keeps host.keys live (no host
  actions fire). It is removed before HoloVerse's controls are restored on return.
- Adds one log line on every dimension entry:  native_input_diag label=... w=1 a=1 ... mouse_mode=...
  Run Indigo Giant, then send me that line (console output, or the stdout log under
  %LOCALAPPDATA%\GLITCHED MATRIX\HoloVerse\logs). It shows what the dimension really registered.
